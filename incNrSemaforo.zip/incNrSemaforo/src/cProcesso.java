public class cProcesso extends Thread {
  int X;
  cPublica publica;
  cSemaforo rc;
  public cProcesso (cPublica p, cSemaforo r) {
    X = 0;
    publica = p;
    rc = r;
  }
  public void run () {
    for (int i=0; i<5; i++) {
        
      rc.down();
      X = publica.A;
      ++X;
      //try {sleep(5);} catch (InterruptedException e) {}
      publica.A = X;
      System.out.print (publica.A + " ");
      
      rc.up();
    }
  }
}