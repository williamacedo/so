public class cPublica {
  int A;
  public cPublica () {
    A = 0;
  }
}
