public class incrementaNumero {
  public static void main (String[] args) {
    cPublica publica     = new cPublica();
    cSemaforo rc = new cSemaforo(1);
    cProcesso processo0 = new cProcesso (publica, rc);

    cProcesso processo1 = new cProcesso (publica, rc);

    processo0.start();

    processo1.start();
  }
}