public class cPublica {
  int senhaRetirada, senhaChamada;

  public cPublica () {
    senhaRetirada = 0;
    senhaChamada = 0;
  }
}