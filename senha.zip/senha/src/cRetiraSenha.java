public class cRetiraSenha extends Thread {
  cPublica publica;
  cSemaforo semaforo;
  cBarbeiroDorminhoco barbeiroDorminhoco;

  public cRetiraSenha (cPublica p, cSemaforo s, cBarbeiroDorminhoco b ) {
    publica = p;
    semaforo = s;
    barbeiroDorminhoco = b;
  }

  public void run () {
      while(true) {
        barbeiroDorminhoco.semCliente.down();
        barbeiroDorminhoco.semaforo.down();
        barbeiroDorminhoco.esperando--;
        barbeiroDorminhoco.semBarbeiro.up();
        barbeiroDorminhoco.semaforo.up();
        publica.senhaRetirada++;
        System.out.println ("Senha " +
                publica.senhaRetirada +
                " retirada");
        semaforo.up();
      }
      ////////////atender cliente
      /////////////////////////

  }
}
