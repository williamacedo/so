class cUsuario extends Thread {
  cPublica publica;
  int id;
  cBarbeiroDorminhoco barbeiroDorminhoco;
  
  public cUsuario (cPublica p, int i ,cBarbeiroDorminhoco b) {
    publica = p;
    id = i;
    barbeiroDorminhoco = b;
  }

  public void run () {
    barbeiroDorminhoco.semaforo.down();
    if(barbeiroDorminhoco.esperando < 10){
        barbeiroDorminhoco.esperando++;
        barbeiroDorminhoco.semCliente.up();
        barbeiroDorminhoco.semaforo.up();
        barbeiroDorminhoco.semBarbeiro.down();
    }else {
        System.out.println("Atendente " + id + "nao esperou");
        barbeiroDorminhoco.semaforo.up();
    }

  }
}