package incrementanr;
public class cVariavelTravamento {
    int varTrav; 
    public cVariavelTravamento(){
        varTrav = 0;
    }
}
