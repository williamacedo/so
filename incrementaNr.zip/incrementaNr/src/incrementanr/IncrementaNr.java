package incrementanr;
public class IncrementaNr {
    public static void main(String[] args) {
        cPublica publica = new cPublica();
        cVariavelTravamento variavelTravamento = new cVariavelTravamento();
        cProcesso processo0 = new cProcesso(publica, variavelTravamento);
        cProcesso processo1 = new cProcesso(publica, variavelTravamento);
        processo0.start();
        processo1.start();
    }
    
}
