package incrementanr;
public class cProcesso extends Thread{
    int x;
    cPublica publica;
    cVariavelTravamento variavelTravamento;
    public cProcesso(cPublica p, cVariavelTravamento vt) {
        x = 0;
        publica = p;
        variavelTravamento = vt;
    }
    
    public void run() {
        for(int i=0; i<5; i++){
            while(variavelTravamento.varTrav==1);
                x = publica.A;
                x++;
                publica.A = x;
                System.out.print (publica.A + " ");
                
                variavelTravamento.varTrav=0;
        }
    }
}
