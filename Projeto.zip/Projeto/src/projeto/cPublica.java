package projeto;

public class cPublica {
    int A;
    int B;
    public cPublica() {
        A = 0;
        B = 1;
        System.out.print (A + " " + B + " ");
    }
            
}