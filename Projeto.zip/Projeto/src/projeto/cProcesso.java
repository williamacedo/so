package projeto;
public class cProcesso extends Thread{
    int n;
    int auxiliar;
    int Processo;
    cPublica publica;
    Peterson peterson;
    public cProcesso(cPublica p, Peterson sp, int processo) {
        n = 4;
        publica = p;
        peterson = sp;
        Processo = processo;
    }
    
    public void run() {
        for(int i=0; i<n; i++){
                peterson.entrarc(0);
                auxiliar = publica.A + publica.B;
                publica.A = publica.B;
                publica.B = auxiliar;
                System.out.print (auxiliar + " ");
                peterson.sairc(0);
        }
    }
}

