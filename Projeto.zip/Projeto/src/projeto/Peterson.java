package projeto;

/**
 *
 * @author william
 */
public class Peterson {
    int[] varTrav = new int[2];
    int turn;
    public void Peterson() {
        varTrav[0] = 0;
        varTrav[1] = 0;
        turn = 0;
    }
    
    public void entrarc(int processo){
        int oOutroprocesso;
        oOutroprocesso = 1 - processo;
        varTrav[processo] = 1;
        turn = processo;
        while(turn == processo && varTrav[oOutroprocesso] == 1);
    }
    
    public void sairc(int processo) {
        varTrav[processo] = 0;
    }
    
}

