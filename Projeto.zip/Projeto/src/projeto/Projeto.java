package projeto;
public class Projeto {
    public static void main(String[] args) {
        cPublica publica = new cPublica();
        Peterson peterson = new Peterson();
        //cVariavelTravamento variavelTravamento = new cVariavelTravamento();
        cProcesso processo0 = new cProcesso(publica, peterson, 0);
        cProcesso processo1 = new cProcesso(publica, peterson, 1);
        processo0.start();
        processo1.start();
    }
    
}
